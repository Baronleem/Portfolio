# Web-Developer
### Technical Skills
- **Languages:** Java, C, JavaScript, SQL, HTML, CSS
- **Tools:** Office 365, Visual Studio, SQL Server, Management Studio, Microsoft Azure
- **Operating Systems:** Windows, Android, iOS, Linux
  
### Education
- **Web-Development and Internet Applications, Diploma**
  - Fanshawe College
  - Location: London, Ontario
  - Duration: January 2022 – Present
 
### Projects




